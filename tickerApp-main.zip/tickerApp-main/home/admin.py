from django.contrib import admin
from .models import Info
from .models import auto_Ticker

# Register your models here.
admin.site.register(Info)
admin.site.register(auto_Ticker)

